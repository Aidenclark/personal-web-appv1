import { profile, people01, people02, people03, facebook, instagram, linkedin, twitter, airbnb, binance, coinbase, dropbox, send, shield, star  } from "../assets";

export const navLinks = [
  {
    id: "home",
    title: "Home",
  },
  {
    id: "features",
    title: "Completed Works",
  },
  {
    id: "about",
    title: "About Me",
  },
];

export const features = [
  {
    id: "feature-1",
    icon: star,
    title: "Stroke Prediction Using Machine Learning",
    content:
      "Learned the foundations of using Tensorflow/Keras to build, train, and evaluate feed forward neural networks on a standard tabular data that can be framed as a classification or a regression problem. Project uses neural networks to take in a set of data from the patient and determines thelikelihood of the patient undergoing a stroke.",
  },
  {
    id: "feature-2",
    icon: star,
    title: "COVID-19 Prediction Using X-Rays",
    content:
      "Developed strong skills in data preprocessing, feature engineering, model selection and optimization, as well as proficiency in working with popular deep learning framework such as TensorFlow and PyTorch. These experiences have enabled me to effectively apply machine learning algorithms to solve complex problems and make data-driven decisions. Report uses two deep learning strategies to create models with high accuracy to reliablepredict COVID-19 in patients. The first strategy is a tweaked simpler convolutional neuralnetwork, while the other strategy uses the more complex VGG-16 architecture."
      ,
  },
  {
    id: "feature-3",
    icon: star,
    title: "User Recommendation System",
    content:
      "Successfully designed a recommendation system for an internal website, utilizing my expertise in collaborative filtering, matrix factorization, and natural language processing techniques. Through this project, I gained hands-on experience with machine learning libraries such as scikit-learn and TensorFlow.",
  },
  {
    id: "feature-4",
    icon: star,
    title: "Created an Operating System",
    content:
      "Created a basic operating system that utilized system calls, library functions, concurrent processes, shared memory, semaphores, message passing, process scheduling, resource management, and memory management. I learned many  fundamental concepts in computer science and operating systems.  ",
  },
  {
    id: "feature-5",
    icon: star,
    title: "Created a Compiler",
    content:
      "Built a working compiler, translating from some subset of a modern programming language into a simple assembly or machine language with available virtual machine for execution. Making a compiler is a complex task that involves understanding many different concepts related to computer science and programming languages like lexical analysis, syntax analysis, semantic analysis, code optimization abd code generation.",
  },
];

export const feedback = [
  {
    id: "feedback-1",
    content:
      "Money is only a tool. It will take you wherever you wish, but it will not replace you as the driver.",
    name: "Herman Jensen",
    title: "Founder & Leader",
    img: people01,
  },
  {
    id: "feedback-2",
    content:
      "Money makes your life easier. If you're lucky to have it, you're lucky.",
    name: "Steve Mark",
    title: "Founder & Leader",
    img: people02,
  },
  {
    id: "feedback-3",
    content:
      "It is usually people in the money business, finance, and international trade that are really rich.",
    name: "Kenn Gallagher",
    title: "Founder & Leader",
    img: people03,
  },
];

export const stats = [
  {
    id: "stats-1",
    title: "Completed works:",
    value: "",
  },

];

export const footerLinks = [
  {
    title: "Useful Links",
    links: [
      {
        name: "GitHub",
        link: "https://github.com/Aidenclark",
      },
      {
        name: "LinkedIn",
        link: "https://www.linkedin.com/in/aidenhclark/",
      },
      {
        name: "aidenhclark@gmail.com",
        link: "aidenhclark@gmail.com",
      },
      {
        name: "920-809-5061",
        link: "",
      },
     
    ],
  },


];

export const socialMedia = [
  {
    id: "social-media-1",
    icon: instagram,
    link: "https://www.instagram.com/",
  },
  {
    id: "social-media-2",
    icon: facebook,
    link: "https://www.facebook.com/",
  },
  {
    id: "social-media-3",
    icon: twitter,
    link: "https://www.twitter.com/",
  },
  {
    id: "social-media-4",
    icon: linkedin,
    link: "https://www.linkedin.com/",
  },
];

export const clients = [
  {
    id: "client-1",
    logo: airbnb,
  },
  {
    id: "client-2",
    logo: binance,
  },
  {
    id: "client-3",
    logo: coinbase,
  },
  {
    id: "client-4",
    logo: dropbox,
  },
];