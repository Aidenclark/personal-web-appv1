import React from 'react'

const Clients = () => {
  return (
    <div>Clients</div>
  )
}

export default Clients