import { moose } from "../assets";
import styles, { layout } from "../style";
import Button from "./Button";

const CardDeal = () => (
  <section id="about" className={layout.section}>
    <div className={layout.sectionInfo}>
      <h2 className={styles.heading2}>
        About me <br className="sm:block hidden" /> 
      </h2>
      <p className={`${styles.paragraph} max-w-[470px] mt-5`}>
      Currently learning to develop accurate and fast machine learning models, and looking for roles in the intersection of data science and software engineering. Hands on
      experience with a degree in computer science and a heavy background in software
      de- velopment using Python and related technologies.
      </p>
      <p className={`${styles.paragraph} max-w-[470px] mt-5`}>
        In college I was a competitive swimmer on the swim team, so on my free time I like to stay active. 
        I also have a dog and his name in Moose. Not pictured is my hamster study buddy- Clarence. 
      </p>

      <Button styles={`mt-10`} />
    </div>

    <div className={layout.sectionImg}>
      <img src={moose} alt="billing" className="w-[100%] h-[100%]" />
    </div>
  </section>
);

export default CardDeal;